module.exports = async function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    const name = (req.query.name || (req.body && req.body.name));
    const responseMessage = name
        ? "Hello, " + name + ". This HTTP triggered function executed successfully."
        : "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.";

    const url = process.env["ghost_blog_url"];//'https://dsblog012.azurewebsites.net';//process.argv[2];
    const key = process.env["ghost_blog_admin_api_key"];//'6244f34b6c5dfc0001b2d36c:517ef592797b024b7ece9088092b6156f2a0d657b5d5e274aa5ce69a3154d9cb';//process.argv[3];
    
    const Promise = require('bluebird');
    const GhostAdminAPI = require('@tryghost/admin-api');
    const api = new GhostAdminAPI({
        url,
        key,
        version: 'v2'
    });

    (async function main() {
            // api.Posts.browse //Admin API automatically includes tags and authors
            const allPosts = await api.posts.browse({limit: 'all'});

            // convert our posts, to a list of promises for requests to the api
            const result = await Promise.mapSeries(allPosts, async (post) => {
                console.log('Deleting %s - %s', post.id, post.title);

                // api.Posts.delete
                let result = await api.posts.delete({id: post.id})
                return Promise.delay(50).return(result);
            });

            console.log(`Deleted ${result.length} posts`);
    }());

    context.res = {
        body: responseMessage
    };
}